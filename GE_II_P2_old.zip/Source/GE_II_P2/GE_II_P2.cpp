// Copyright Epic Games, Inc. All Rights Reserved.

#include "GE_II_P2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, GE_II_P2, "GE_II_P2" );
 